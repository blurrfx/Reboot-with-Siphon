#pragma once

#include "Actor.h"

class AFortAthenaPatrolPath : public AActor
{
public:
};
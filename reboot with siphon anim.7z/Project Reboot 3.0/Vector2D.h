#pragma once

struct FVector2D
{
	float X;
	float Y;
};
#pragma once

#include "FortGameMode.h"

#include "Engine.h"

class AFortGameModeZone : public AFortGameMode
{
public:
	static UClass* StaticClass();
};
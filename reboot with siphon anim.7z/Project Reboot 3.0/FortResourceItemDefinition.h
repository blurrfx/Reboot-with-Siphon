#pragma once

#include "FortWorldItemDefinition.h"

class UFortResourceItemDefinition : public UFortWorldItemDefinition
{
public:
};